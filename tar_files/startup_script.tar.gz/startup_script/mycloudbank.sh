#!/bin/bash


cd /usr/local/src/apps/mycloudbank/
nodejs app.js


