#!/bin/bash

cd /usr/local/src/apps/app.poster_v2/
nodejs app.js 
