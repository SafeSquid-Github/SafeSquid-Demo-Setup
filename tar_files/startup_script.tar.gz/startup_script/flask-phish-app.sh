#!/bin/bash

python3 /usr/local/src/apps/flask-phish-app/flask-p-app.py 
